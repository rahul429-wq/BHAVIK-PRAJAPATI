window.onload = () => {
  var a = new Date();
  var days = new Array(7);
  days[0] = "Sunday";
  days[1] = "Monday";
  days[2] = "Tuesday";
  days[3] = "Wednesday";
  days[4] = "Thursday";
  days[5] = "Friday";
  days[6] = "Saturday";
  var r = days[a.getDay()];
  document.getElementById("dayname").innerHTML = r;
};
// !menu

let ham = document.getElementById("hamburger");
let sidebar = document.querySelector(".sidebar");

ham.addEventListener("click", () => {
  sidebar.classList.toggle("toggle");
});
// !ondoclick
document.onclick = function (e) {
  // console.log(e.target.id);
  if (
    e.target.id == "one" ||
    e.target.id == "two" ||
    e.target.id == "three" ||
    e.target.id == "four" ||
    e.target.id == "five"
  ) {
    sidebar.classList.toggle("toggle");
    // console.log("hello");
    // navlist.classList.toggle("show");
  } else {
    console.log("fellow");
  }
};
// !ondoclick

// !scrolltop

mybutton = document.getElementById("myBtn");

// When the user scrolls do wn 20px from the top of the document, show the button
window.onscroll = function () {
  scrollFunction();
};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}

var btnclose = document.getElementById("closebtn");
btnclose.addEventListener("click", () => {
  sidebar.classList.toggle("toggle");
});

var sec1 = document.getElementById("sec1");

// sec1.onclick = () => {
//   sidebar.classList.toggle("toggle");
// };
